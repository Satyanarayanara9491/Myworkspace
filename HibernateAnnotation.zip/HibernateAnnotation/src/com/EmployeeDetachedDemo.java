package com;
//update the specific details
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeDetachedDemo {
public static void main(String[] args) {
	SessionFactory session_factory =new Configuration().configure().buildSessionFactory();
	//Session session=session_factory.openSession();
	Transaction tr=null;
	try{
		Session session=session_factory.getCurrentSession();
	tr=session.beginTransaction();
	Employee e=(Employee)session.get(Employee.class, 24);
	
	System.out.println(e);
	tr.commit();
	session.close();
	e.setEmp_name("kalyan");
	Session session2 = session_factory.getCurrentSession();
	session2.beginTransaction();
	session2.update(e);
	session2.getTransaction().commit();
	session2.close();
	//session_factory.close();
	}
	catch(Exception e){
	//	if(tr!=null){
		//	tr.rollback();
			e.printStackTrace();
		}
	}
	
	}
//}
