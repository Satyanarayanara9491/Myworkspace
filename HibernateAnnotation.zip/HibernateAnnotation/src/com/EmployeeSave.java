package com;

import java.sql.Time;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeSave {
	public static void main(String[] args) {
		SessionFactory ss=new Configuration().configure().buildSessionFactory();
		Session sess=ss.openSession();
		Transaction tx=null;
		try{
		tx=sess.beginTransaction();
		Employee e=new Employee();
		e.setEmp_id(101);
		e.setEmp_name("john");
	
		Employee e1=new Employee();
	e1.setEmp_id(110);
		e1.setEmp_name("mark");
		e.setDob(new Date());
		Time t=new Time(12, 00, 00);
		Integer result=(Integer)sess.save(e);
		System.out.println("result "+result);
		sess.save(e);
		
		
		Integer result1=(Integer)sess.save(e1);
		System.out.println("result "+result1);
		sess.save(e1);
		//commit the transaction
	
		tx.commit();
		System.out.println("Employee object saved........");
		
		}
		catch(Exception e){
			if(tx!=null){
				tx.rollback();
				e.printStackTrace();
			}
		}
		finally{
			ss.close();
			sess.close();
		}
	}
}
