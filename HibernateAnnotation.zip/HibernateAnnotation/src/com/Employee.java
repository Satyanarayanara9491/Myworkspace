package com;

import java.sql.Time;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="EMP")
public class Employee {
	@Id
	//@GeneratedValue
	//@GeneratedValue(strategy=GenerationType.AUTO) Both are correct
	//@GeneratedValue(strategy=GenerationType.SEQUENCE="my_generator")
	@GeneratedValue(strategy=GenerationType.TABLE,generator="my_table_generator")
	@TableGenerator(name="my_table_generator",table="My_Generator_table",initialValue=1,allocationSize=1)
	
	@Column(name="ID")
	private int emp_id;
	@Column(name="name")
	private String emp_name;
	@Temporal(TemporalType.DATE)
	private Date dob;
	//@Temporal(TemporalType.TIME)
	//private Time curr;
	
	
//	@Temporal(TemporalType.TIME)
//	private Time curr;
	public Employee(){
	
	}
	
	//Time curr
	
	public Employee(int emp_id, String emp_name, Date dob) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.dob = dob;
	//	this.curr = curr;
	}

	public int getEmp_id() {
	return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

//	public Time getCurr() {
	//	return curr;
//	}

//	public void setCurr(Time curr) {
	//	this.curr = curr;
//	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", dob=" + dob ;
	}
}
