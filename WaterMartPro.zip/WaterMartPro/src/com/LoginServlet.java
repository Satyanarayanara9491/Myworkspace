package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.LoginBean;
import dao.UserDAOImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		LoginBean lb = new LoginBean();
		lb.setUsername(request.getParameter("username"));
		lb.setPassword(request.getParameter("password"));
		UserDAOImpl ob = new UserDAOImpl();
		boolean res = ob.loginValid(lb);

		if (res) {
			System.out.println("Login Successfull!");

			HttpSession session = request.getSession();
			session.setAttribute("uname", lb.getUsername());
			response.sendRedirect("home.jsp?uname=" + lb.getUsername());
		} else {
			PrintWriter out = response.getWriter();
			out.write("Invalid username or password..");
			RequestDispatcher rd = request.getRequestDispatcher("login.html");
			rd.include(request, response);
		}
	}

}
