package dao;

import java.sql.ResultSet;

import bean.LoginBean;
import bean.UserBean;

public interface UserDAO {
	boolean insertUser(UserBean ub);

	boolean loginValid(LoginBean lb);

	boolean feedback(String uname, String feedback);

	ResultSet cartItems(String username);
}
