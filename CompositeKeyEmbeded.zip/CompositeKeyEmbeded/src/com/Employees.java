package com;

import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="emp1")
public class Employees{
	
	@EmbeddedId
	private EmployeeAccKey emp_acc_key;
	private String emp_name;
	public Employees(){
		
	}
	
	public Employees(EmployeeAccKey emp_acc_key, String emp_name) {
		super();
		this.emp_acc_key = emp_acc_key;
		this.emp_name = emp_name;
	}
	public EmployeeAccKey getEmp_acc_key() {
		return emp_acc_key;
	}
	public void setEmp_acc_key(EmployeeAccKey emp_acc_key) {
		this.emp_acc_key = emp_acc_key;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	
}
