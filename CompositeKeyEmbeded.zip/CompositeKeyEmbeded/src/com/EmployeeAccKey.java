package com;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class EmployeeAccKey implements Serializable{


	private int emp_id;
	
	private int acc_no;
	
	public EmployeeAccKey(){
		
	}

	public EmployeeAccKey(int emp_id, int acc_no) {
		super();
		this.emp_id = emp_id;
		this.acc_no = acc_no;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public int getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}

	@Override
	public int hashCode() {
		int result = 3;
		return result*emp_id+acc_no;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeAccKey other = (EmployeeAccKey) obj;
		if (acc_no != other.acc_no)
			return false;
		if (emp_id != other.emp_id)
			return false;
		return true;
	}
		
}
