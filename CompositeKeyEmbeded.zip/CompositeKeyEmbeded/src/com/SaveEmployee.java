package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SaveEmployee {
public static void main(String[] args) {
	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	Session ss=sf.openSession();
	Transaction t=ss.beginTransaction();
	Employees e1=new Employees(new EmployeeAccKey(10000,200001),"karan");
	
	ss.save(e1);
	t.commit();
	System.out.println("employee saved ");
	ss.close();
	sf.close();
}
}
