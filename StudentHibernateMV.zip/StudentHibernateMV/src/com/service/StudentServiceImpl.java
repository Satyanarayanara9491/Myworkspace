package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Student;
import com.dao.StudentDAOImpl;

@Service
public class StudentServiceImpl implements StudentService {

 @Autowired
private StudentDAOImpl studentDAOImpl;

 @Override
public void saveStudent(Student student) {
// TODO Auto-generated method stub
studentDAOImpl.saveStudent(student);
}

 @Override
public List<Student> getAllStudents() {
// TODO Auto-generated method stub
return studentDAOImpl.getAllStudents();
}

 @Override
public void deleteStudent(Integer stud_id) {
// TODO Auto-generated method stub
studentDAOImpl.deleteStudent(stud_id);
}

 @Override
public Student getStudentById(Integer stud_id) {
// TODO Auto-generated method stub
return studentDAOImpl.getStudentById(stud_id);
}

 @Override
public void updateStudent(Student student) {
// TODO Auto-generated method stub
studentDAOImpl.updateStudent(student);
}
}