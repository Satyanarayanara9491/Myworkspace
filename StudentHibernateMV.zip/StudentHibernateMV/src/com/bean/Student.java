package com.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.osgi.service.component.annotations.Component;

//@Entity
//@Table(name = "StudentMVC")

public class Student implements Serializable{

 //@Id
//@GeneratedValue(strategy = GenerationType.AUTO)
private int stud_id;
private String stud_name;
private String stud_course;
public Student() {
// TODO Auto-generated constructor stub
}

 public Student(int stud_id, String stud_name, String stud_course) {
super();
this.stud_id = stud_id;
this.stud_name = stud_name;
this.stud_course = stud_course;
}

 public int getStud_id() {
return stud_id;
}

 public void setStud_id(int stud_id) {
this.stud_id = stud_id;
}

 public String getStud_name() {
	 return stud_name;
 	}
 public void setStud_name(String stud_name) {
	 	this.stud_name = stud_name;
 	}
 	
 public String getStud_course() { 
	 return stud_course; 
 }

 public void setStud_course(String stud_course) {
	 this.stud_course = stud_course;
}

 @Override
 		public String toString() {
return "Student [stud_id=" + stud_id + ", stud_name=" + stud_name + ", stud_course=" + stud_course + "]";
}

}