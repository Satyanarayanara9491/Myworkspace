package com.dao;

import java.util.List;

import com.bean.Student;

public interface StudentDAO {
public void saveStudent(Student student);
public List<Student> getAllStudents();
public void deleteStudent(Integer stud_id);
public Student getStudentById(Integer stud_id);
public void updateStudent(Student student);
}