package com.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import com.bean.Student;

@Repository
public class StudentDAOImpl implements StudentDAO {

 @Autowired
private HibernateTemplate hibernateTemplate;

 @Override
public void saveStudent(Student student) {
// TODO Auto-generated method stub
hibernateTemplate.save(student);
}

 @Override
public List<Student> getAllStudents() {
// TODO Auto-generated method stub
	 return hibernateTemplate.find("from Student");
	 
 }
 @Override
public void deleteStudent(Integer stud_id) {
// TODO Auto-generated method stub
hibernateTemplate.delete(getStudentById(stud_id));
 }
 @Override
public Student getStudentById(Integer stud_id) {
return hibernateTemplate.get(Student.class, stud_id);
 }
 @Override
public void updateStudent(Student student) {
// TODO Auto-generated method stub
	 
Student update_student = getStudentById(student.getStud_id());


update_student.setStud_name(student.getStud_name());


update_student.setStud_course(student.getStud_course());


hibernateTemplate.update(update_student);


 	}
}