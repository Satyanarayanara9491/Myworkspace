package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Student;
import com.service.StudentServiceImpl;

@Controller

public class StudentController {

 @Autowired
private StudentServiceImpl studentServiceImpl;
/*
* @RequestMapping(value = "studentForm") public ModelAndView student() {
* ModelAndView model = new ModelAndView("studentForm", "student", new
* Student()); return model; }


 	/*
 	* @RequestMapping(value = "saveStudent", method = RequestMethod.POST) public
	* String saveStudent(@ModelAttribute Student student, ModelMap map) {
	* map.addAttribute("msg", "Student Added"); map.addAttribute(new Student());
	* System.out.println("Student = " + student);
	* studentServiceImpl.saveStudent(student); return "redirect:/studentForm"; }
	*/
 @RequestMapping(value="/a")
public String name(Model map) {
	 Student st=new Student();
	 map.addAttribute("st",st);
	return "studentForm";
}
 

 	@RequestMapping(value = "saveStudent", method = RequestMethod.POST)
 	public String saveStudent(@ModelAttribute Student student, ModelMap map) {

 	if (student.getStud_id() == 0) {
System.out.println("Student added");
studentServiceImpl.saveStudent(student);
} else {
System.out.println("Student Updated");
studentServiceImpl.updateStudent(student);
}

 map.addAttribute(new Student());
return "redirect:/studentForm";
}

 @RequestMapping(value = "studentForm")
public ModelAndView listStudents() {
List<Student> list_student = studentServiceImpl.getAllStudents();
ModelAndView model = new ModelAndView("studentForm", "student", new Student());
model.addObject("list_student", list_student);
model.setViewName("studentForm");
return model;
}

 @RequestMapping("deleteStudent/{stud_id}")
public String deleteStudent(@PathVariable("stud_id") int stud_id) {
studentServiceImpl.deleteStudent(stud_id);
System.out.println("Student Deleted");
return "redirect:/studentForm";
}

 @RequestMapping("updateStudent/{stud_id}")
public ModelAndView updateStudent(@PathVariable("stud_id") int stud_id) {
Student student = studentServiceImpl.getStudentById(stud_id);
List<Student> list_student = studentServiceImpl.getAllStudents();
ModelAndView model = new ModelAndView();
model.addObject("student", student);
model.addObject("list_student", list_student);
model.addObject("student", student);
model.setViewName("studentForm");
System.out.println("Student Editing");
return model;

 }

}