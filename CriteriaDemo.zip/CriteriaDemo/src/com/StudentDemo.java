package com;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import bean.Student;

public class StudentDemo {
	 public static void main(String[] args) {
	        // TODO Auto-generated method stub
	        SessionFactory session_factory = new Configuration().configure().buildSessionFactory();
	        Session session = session_factory.getCurrentSession();
	        Criteria criteria=null;
	        session.beginTransaction();
	        criteria=session.createCriteria(Student.class);
	        List<Student> list=criteria.list();
	        System.out.println(list);
	        
	        System.out.println("equaity ");
	        criteria=session.createCriteria(Student.class);
	        criteria.add(Restrictions.eq("st_id",75));
	        
	        List<Student> list_prod=criteria.list();
	        System.out.println(list_prod);
	        
	        System.out.println("greater ");
	        criteria=session.createCriteria(Student.class);
	        criteria.add(Restrictions.gt("st_marks", 50.0));
	        List<Student> l=criteria.list();
	        System.out.println(l);
	        
	        System.out.println("like ");
	        criteria=session.createCriteria(Student.class);
	        criteria.add(Restrictions.gt("st_name", "r%"));
	        List<Student> li=criteria.list();
	        System.out.println(li);
	        
	        System.out.println("Logical Expression or Restriction ");
	        criteria=session.createCriteria(Student.class);
	        Criterion criterion1=Restrictions.like("st_name", "r%");
	        Criterion criterion2=Restrictions.eq("st_marks",90);
	        LogicalExpression exp1=Restrictions.or(criterion1, criterion2);
	        criteria.add(exp1);
	        List<Student> list1=criteria.list();
	        System.out.println(list1);
	        
	        System.out.println("Projection max");
	        criteria=session.createCriteria(Student.class);
	        criteria.setProjection(Projections.max("st_marks"));
	        List<Student> list2=criteria.list();
	        System.out.println(list2);
	        
	        
	        
	        
	        System.out.println("order descending ");
	        criteria=session.createCriteria(Student.class);
	        criteria.addOrder(Order.desc("st_marks"));
	        List<Student> list3=criteria.list();
	        System.out.println(list3);
	        
	        session.getTransaction().commit();
	        session.close();
	        session_factory.close();
	  
	 }
}
