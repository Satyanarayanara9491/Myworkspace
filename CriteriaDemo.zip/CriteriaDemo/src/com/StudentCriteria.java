package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import bean.Student;
public class StudentCriteria{
public static void main(String[] args) {
	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	Session ss=sf.openSession();
	Transaction t=ss.beginTransaction();
	
	Student st=new Student();
	st.setSt_name("ram");
	st.setSt_marks(90.00);
	ss.save(st);
	ss.getTransaction().commit();
	t.commit();
}
}
