package bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	@GeneratedValue
	private int st_id;
	private String st_name;
	private double st_marks;
	
	public Student(){
		
	}

	@Override
	public String toString() {
		return "Student [st_id=" + st_id + ", st_name=" + st_name + ", st_marks=" + st_marks + "]";
	}

	public int getSt_id() {
		return st_id;
	}

	public void setSt_id(int st_id) {
		this.st_id = st_id;
	}

	public String getSt_name() {
		return st_name;
	}

	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}

	public double getSt_marks() {
		return st_marks;
	}

	public void setSt_marks(double st_marks) {
		this.st_marks = st_marks;
	}

	public Student(int st_id, String st_name, double st_marks) {
		super();
		this.st_id = st_id;
		this.st_name = st_name;
		this.st_marks = st_marks;
	}
	
  
}
