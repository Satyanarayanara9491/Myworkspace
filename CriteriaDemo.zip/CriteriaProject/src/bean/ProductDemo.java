
    
package bean;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import bean.Product;


public class ProductDemo {


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        SessionFactory session_factory = new Configuration().configure().buildSessionFactory();
        Session session = session_factory.getCurrentSession();
        Criteria criteria=null;
        session.beginTransaction();
        criteria=session.createCriteria(Product.class);
        List<Product> list=criteria.list();
        System.out.println(list);
        
        System.out.println("equaity ");
        criteria=session.createCriteria(Product.class);
        criteria.add(Restrictions.eq("product_name", "speakers"));
        
        List<Product> list_prod=criteria.list();
        System.out.println(list_prod);
        
        System.out.println("greater ");
        criteria=session.createCriteria(Product.class);
        criteria.add(Restrictions.gt("product_price", 25000.0));
        List<Product> l=criteria.list();
        System.out.println(l);
        
        System.out.println("like ");
        criteria=session.createCriteria(Product.class);
        criteria.add(Restrictions.gt("product_name", "sam%"));
        List<Product> li=criteria.list();
        System.out.println(li);
        
        System.out.println("Logical Expression or Restriction ");
        criteria=session.createCriteria(Product.class);
        Criterion criterion1=Restrictions.like("product_name", "sam%");
        Criterion criterion2=Restrictions.eq("product_price",40000.0);
        LogicalExpression exp1=Restrictions.or(criterion1, criterion2);
        criteria.add(exp1);
        List<Product> list1=criteria.list();
        System.out.println(list1);
        
        System.out.println("Projection max");
        criteria=session.createCriteria(Product.class);
        criteria.setProjection(Projections.max("product_price"));
        List<Product> list2=criteria.list();
        System.out.println(list2);
        
        
        
        System.out.println("order descending ");
        criteria=session.createCriteria(Product.class);
        criteria.addOrder(Order.desc("product_price"));
        List<Product> list3=criteria.list();
        System.out.println(list3);
        
        session.getTransaction().commit();
        session.close();
        session_factory.close();
  
        

    }
}







