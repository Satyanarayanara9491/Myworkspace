
package com.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.bean.Employee;



@Repository
public class DaoImpl implements DAO {
	
	@Autowired 
	private HibernateTemplate hibernateTemplate;

	@Override
	public void saveUser(Employee user) {
	 hibernateTemplate.save(user);
	 System.out.println("inserted successfully........");
	}

}