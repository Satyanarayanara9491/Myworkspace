package com.dao;

import com.bean.Employee;

public interface DAO {
	public void saveUser(Employee user);
 
}
