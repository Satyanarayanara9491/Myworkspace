package com.service;
import com.bean.Employee;
public interface Service {
	public void saveUser(Employee user);
}





