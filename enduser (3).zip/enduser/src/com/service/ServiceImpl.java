package com.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.bean.Employee;
import com.dao.DaoImpl;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service{
   
	@Autowired
	private DaoImpl dao;
	@Override
	public void saveUser(Employee user) {
		dao.saveUser(user);
	}

}
