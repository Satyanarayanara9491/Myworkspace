package com.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.staticmock.MockStaticEntityMethods;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bean.*;
import com.dao.DaoImpl;
import com.service.Service;

@Controller
public class MyController {

	@Autowired
	private DaoImpl imp;
	
public Employee user;
@RequestMapping("/login")
public String docheck(){
	System.out.println("hello");
	return "login";
}
@RequestMapping("/next")
public ModelAndView next(ModelAndView model,@RequestParam("id") String id,@RequestParam("name") String name,@RequestParam("designation") String dependent,@RequestParam("sal") String sal){
    int emp_id=Integer.parseInt(id);
	int salary=Integer.parseInt(sal);
	user=new Employee();
 	user.setEmp_id(emp_id);
 	user.setEmp_name(name);
 	user.setSalary(salary);
 	user.setDesignation(dependent);
 	
	imp.saveUser(user);
	model.addObject(user);
	model.setViewName("success");
	
	return model;
	
}
}